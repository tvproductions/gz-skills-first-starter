# Invented publisher binding fixture
Read publisher-binding.md as the actual starter binding. Governing policy snapshot is ../canonical-policy.md, identical to its selected source. Actual publisher ADRs are untouched; this case has its own fictional decision. Existing collection is docs/architecture/decisions.
