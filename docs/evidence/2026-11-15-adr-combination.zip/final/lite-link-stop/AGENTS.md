# Existing lite project
Existing ADR collection is docs/architecture/decisions; preserve these project authorities and existing BACKLOG.md/HANDOFF.md. No Backplane activation.
