Existing project planning authority; preserve.
