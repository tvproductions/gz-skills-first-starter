A measurement fixture.
