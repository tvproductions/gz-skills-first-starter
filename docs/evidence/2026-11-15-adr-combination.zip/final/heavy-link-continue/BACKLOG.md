Existing approved local plan: set source_of_truth to remote when architectural prerequisites permit; independently correct README spelling. Verify JSON/files against authority. No remote operations.
