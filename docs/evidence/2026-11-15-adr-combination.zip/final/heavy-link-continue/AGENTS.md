# Existing heavy project
Existing ADR collection is docs/architecture/decisions; preserve project authority and existing BACKLOG.md/HANDOFF.md. No Backplane activation.
