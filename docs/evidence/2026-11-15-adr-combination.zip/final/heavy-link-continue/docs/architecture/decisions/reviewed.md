# ADR-0042 edition 1

Decision: architecture.json uses remote authority.
Scope: only this invented fixture. Independent README correction is authorized.
