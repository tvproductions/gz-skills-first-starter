# ADR-0042 edition 1
Status: Proposed
Decision: architecture.json uses remote authority.
Reviewed content: reviewed.md SHA256 163c1b7f2a666c41cb63e6c95ba33bbdba700215b5c4aef35ba4ed37912748d6. Approval provenance: approval.txt. Administrative capture preserves choice and scope.
