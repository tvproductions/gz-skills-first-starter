A measurment fixture.
